extern const unsigned short rle1[];
extern const unsigned short rle2[];
extern const unsigned short rle3[];
